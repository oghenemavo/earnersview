<div class="alert alert-icon alert-{{ $attributes['type'] }}" role="alert">
    <em class="icon ni ni-alert-circle"></em> 
    {{ $attributes['message'] }} 
</div>