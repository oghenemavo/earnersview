<div class="alert alert-icon alert-<?php echo e($attributes['type']); ?>" role="alert">
    <em class="icon ni ni-alert-circle"></em> 
    <?php echo e($attributes['message']); ?> 
</div><?php /**PATH C:\xampp\htdocs\earnersview\resources\views/components/alert.blade.php ENDPATH**/ ?>