<!DOCTYPE html>
<html lang="en" class="js">
    <head>
        <base href="../">
        <meta charset="utf-8">
        <meta name="author" content="Softnio">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="A powerful and conceptual apps base dashboard template that especially build for developers and programmers.">
        <!-- Fav Icon  -->
        <link rel="shortcut icon" href="<?php echo e(asset('dashboard/images/favicon.png')); ?>">
        <!-- Page Title  -->
        <title><?php echo e($page_title ?? 'Admin Dashboard'); ?></title>
        <!-- StyleSheets  -->
        <link rel="stylesheet" href="<?php echo e(asset('dashboard/css/dashlite.css?ver=2.8.0')); ?>">
        <link id="skin-default" rel="stylesheet" href="<?php echo e(asset('dashboard/css/theme.css?ver=2.8.0')); ?>">
        <?php echo $__env->yieldPushContent('styles'); ?>
    </head>

    <body class="nk-body bg-white has-sidebar ">
        <div class="nk-app-root">
            <!-- main @s  -->
            <div class="nk-main ">

                <!-- sidebar @s  -->
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.sidebar','data' => []]); ?>
<?php $component->withName('admin.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <!-- sidebar @e  -->
                
                <!-- wrap @s  -->
                <div class="nk-wrap ">
                    
                    <!-- main header @s  -->
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.header','data' => []]); ?>
<?php $component->withName('admin.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <!-- main header @e  -->

                    <!-- content @s  -->
                    <div class="nk-content nk-content-fluid">
                        <div class="container-xl wide-lg">
                            <div class="nk-content-body">

                                <!-- notifications alert -->
                                <?php $__currentLoopData = ['primary', 'secondary', 'success', 'info', 'warning', 'danger', 'gray', 'light']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(session()->has($alert)): ?>
                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => ['type' => ''.e($alert).'','message' => session()->get($alert)]]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => ''.e($alert).'','message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session()->get($alert))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- notifications alert -->

                                <!-- main content -->
                                <?php echo $__env->yieldContent('content'); ?>
                                <!-- main content -->
                            </div>
                        </div>
                    </div>
                    <!-- content @e  -->
                    <!-- footer @s  -->
                    <div class="nk-footer">
                        <div class="container-fluid">
                            <div class="nk-footer-wrap">
                                <div class="nk-footer-copyright"> &copy; 2020 Earners View.
                                </div>
                                <div class="nk-footer-links">
                                    <ul class="nav nav-sm">
                                        <li class="nav-item"><a class="nav-link" href="#">Terms</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#">Privacy</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#">Help</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- footer @e  -->
                </div>
                <!-- wrap @e  -->
            </div>
            <!-- main @e  -->
        </div>
        <!-- app-root @e  -->
        <!-- JavaScript -->
        <script src="<?php echo e(asset('dashboard/js/bundle.js?ver=2.8.0')); ?>"></script>
        <script src="<?php echo e(asset('dashboard/js/scripts.js?ver=2.8.0')); ?>"></script>
        <script src="<?php echo e(asset('dashboard/js/charts/gd-default.js?ver=2.8.0')); ?>"></script>

        <?php echo $__env->yieldPushContent('scripts'); ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\earnersview\resources\views/layouts/admin.blade.php ENDPATH**/ ?>