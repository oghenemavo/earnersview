<!DOCTYPE html>
<html lang="en" class="js">
    <head>
        <base href="<?php echo e(url('')); ?>">
        <meta charset="utf-8">
        <meta name="author" content="Softnio">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="A powerful and conceptual apps base dashboard template that especially build for developers and programmers.">
        <!-- Fav Icon  -->
        <link rel="shortcut icon" href="<?php echo e(asset('dashboard/images/favicon.png')); ?>">
        <!-- Page Title  -->
        <title><?php echo e($page_title ?? 'Protected Area'); ?></title>
        <!-- StyleSheets  -->
        <link rel="stylesheet" href="<?php echo e(asset('dashboard/css/dashlite.css?ver=2.8.0')); ?>">
        <link id="skin-default" rel="stylesheet" href="<?php echo e(asset('dashboard/css/theme.css?ver=2.8.0')); ?>">
        <?php echo $__env->yieldPushContent('styles'); ?>
    </head>
    <body class="nk-body bg-white npc-general pg-auth">
        <div class="nk-app-root">
            <!-- main @s  -->
            <div class="nk-main ">
                <!-- wrap @s  -->
                <div class="nk-wrap nk-wrap-nosidebar">
                    
                    <!-- notifications alert -->
                    <?php $__currentLoopData = ['primary', 'secondary', 'success', 'info', 'warning', 'danger', 'gray', 'light']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(session()->has($alert)): ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => ['type' => ''.e($alert).'','message' => session()->get($alert)]]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => ''.e($alert).'','message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session()->get($alert))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- notifications alert -->

                    <!-- content @s  -->
                    <div class="nk-content ">
                        <div class="nk-block nk-block-middle nk-auth-body  wide-xs">
                            <div class="brand-logo pb-4 text-center">
                                <a href="html/index.html" class="logo-link">
                                    <img class="logo-light logo-img logo-img-lg" src="<?php echo e(asset('images/logo.png')); ?>" srcset="<?php echo e(asset('images/logo2x.png 2x')); ?>" alt="logo">
                                    <img class="logo-dark logo-img logo-img-lg" src="<?php echo e(asset('images/logo-dark.png')); ?>" srcset="<?php echo e(asset('images/logo-dark2x.png 2x')); ?>" alt="logo-dark">
                                </a>
                            </div>
                            <div class="card card-bordered">
                                <!-- Protected Area -->
                                <?php echo $__env->yieldContent('content'); ?>
                                <!-- Protected Area -->
                            </div>
                        </div>
                        <div class="nk-footer nk-auth-footer-full">
                            <div class="container wide-lg">
                                <div class="row g-3">
                                    <div class="col-lg-6 order-lg-last">
                                        <ul class="nav nav-sm justify-content-center justify-content-lg-end">
                                            <li class="nav-item">
                                                <a class="nav-link" href="#">Terms & Condition</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="#">Privacy Policy</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="#">Help</a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="nk-block-content text-center text-lg-left">
                                            <p class="text-soft">&copy; 2019 Earner's View. All Rights Reserved.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- wrap @e  -->
                </div>
                <!-- content @e  -->
            </div>
            <!-- main @e  -->
        </div>
        <!-- app-root @e  -->
        <!-- JavaScript -->
        <script src="<?php echo e(asset('dashboard/js/bundle.js?ver=2.8.0')); ?>"></script>
        <script src="<?php echo e(asset('dashboard/js/scripts.js?ver=2.8.0')); ?>"></script>
        <?php echo $__env->yieldPushContent('scripts'); ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\earnersview\resources\views/layouts/protected.blade.php ENDPATH**/ ?>