<div class="gen-account-holder">
    <a href="javascript:void(0)" id="gen-user-btn"><i class="fa fa-user"></i></a>
    <div class="gen-account-menu">
        <ul class="gen-account-menu">
            <!-- Pms Menu -->
            <li>
                <a href="<?php echo e(route('user.profile')); ?>"><i class="fa fa-user"></i>
                    Profile
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('user.report.earnings')); ?>"><i class="fa fa-list"></i>
                    Earnings 
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('user.report.referrals')); ?>"><i class="fa fa-users"></i>
                    Referrals
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('user.report.transactions')); ?>"><i class="fa fa-list"></i>
                    Transactions History 
                </a>
            </li>
            <!-- Library Menu -->
            <li>
                <a href="<?php echo e(route('user.settings')); ?>"><i class="fa fa-cog"></i>
                    Settings 
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault(); document.getElementById('logout-form').submit();" >
                    <i class="fas fa-sign-out-alt"></i>
                    Log out 
                </a>
            </li>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </ul>
    </div>
</div><?php /**PATH C:\xampp\htdocs\earnersview\resources\views/components/nav.blade.php ENDPATH**/ ?>