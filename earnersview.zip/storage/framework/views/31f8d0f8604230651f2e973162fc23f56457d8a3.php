

<?php $__env->startSection('content'); ?>
<!-- breadcrumb -->
<div class="gen-breadcrumb" style="background-image: url('images/background/asset-25.jpeg');">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-12">
                <nav aria-label="breadcrumb">
                    <div class="gen-breadcrumb-title">
                        <h1>
                            Profile
                        </h1>
                    </div>
                    <div class="gen-breadcrumb-container">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><i class="fas fa-home mr-2"></i>Dashboard</a></li>
                            <li class="breadcrumb-item active">Profile</li>
                        </ol>
                    </div>
                </nav>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb -->


<!-- Register -->
<section class="gen-section-padding-3 gen-library">
    <div class="container">
        
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                
                <!-- notifications alert -->
                <?php $__currentLoopData = ['primary', 'secondary', 'success', 'info', 'warning', 'danger', 'gray', 'light']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(session()->has($alert)): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => ['type' => ''.e($alert).'','message' => session()->get($alert)]]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => ''.e($alert).'','message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session()->get($alert))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- notifications alert -->
                
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.membership','data' => []]); ?>
<?php $component->withName('membership'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

            </div>

            <div class="col-lg-8 offset-lg-2">
                <form>
                    <?php echo csrf_field(); ?>
                    <div class="profile">
                        <h2>Profile</h2>

                        <div class="form-group">
                            <label for="current">Name</label>
                            <input type="text" id="current" class="form-control" readonly value="<?php echo e(auth()->user()->name); ?>">
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="text" id="email" class="input form-control" readonly value="<?php echo e(auth()->user()->email); ?>">
                        </div>

                        <div class="form-group">
                            <label for="referral">Referral Code</label>
                            <input type="text" id="referral" class="input form-control" value="<?php echo e(auth()->user()->referral_code); ?>"  readonly >
                        </div>

                        <div class="form-group">
                            <label for="bank">Bank Name</label>
                            <input type="text" id="bank" class="input form-control" value="<?php echo e(auth()->user()->bank_account ?? 'Not filled'); ?>" readonly >
                        </div>

                        <div class="form-group">
                            <label for="account">Account Number</label>
                            <input type="text" id="account" class="input form-control" value="<?php echo e(auth()->user()->account_name ?? 'Not filled'); ?>" readonly>
                        </div>

                        <a href="<?php echo e(route('user.account')); ?>" class="btn btn-outline-primary mt-3"><i class="fas fa-edit mr-2"></i>Edit Profile</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<!-- Register -->


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(function() {
            var res = new Promise(function (resolve, reject) {
                $.ajax({
                    url: `<?php echo e(asset('app/js/banks.json')); ?>`,
                    dataType: "json",
                    success: function (response) {
                        resolve(response);
                    },
                    error: function (err) {
                        reject(err);
                    }
                });
            });

            res.then(data => {
                if (!$.isEmptyObject(data)) {
                    $.each(data.data, function(key, value) {
                        // if (value.code) {
                        //     bank_account.append($('<option selected></option>').val(value.code).text(value.name));
                        // } else {
                        //     bank_account.append($('<option></option>').val(value.code).text(value.name));
                        // }
                        if (value.code == `<?php echo e(auth()->user()->bank_code); ?>`) {
                            $('#bank').val(value.name);
                        }
                    });
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\earnersview\resources\views/user/dashboard/profile.blade.php ENDPATH**/ ?>